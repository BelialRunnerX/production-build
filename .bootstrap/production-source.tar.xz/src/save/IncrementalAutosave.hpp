#pragma once
#include <cstdint>
#include <vector>
#include <unordered_map>
namespace elysium {
// Intended function: Schedule touched-shard/chunk publication batches by dirty generation, urgency, and transaction budget.
struct IncrementalAutosaveOp { std::uint64_t id{0}, owner{0}, ref{0}; double value{0.0}; std::uint32_t flags{0}; };
struct IncrementalAutosaveData { std::uint64_t revision{0}, id{0}, owner{0}, ref{0}; double value{0.0}; std::uint32_t flags{0}; bool live{false}; };
class IncrementalAutosaveStore { public: bool apply(const IncrementalAutosaveOp&); bool erase(std::uint64_t); const IncrementalAutosaveData* find(std::uint64_t) const; std::vector<IncrementalAutosaveData> snapshot() const; void clear(); private: std::uint64_t revision_{1}; std::unordered_map<std::uint64_t,IncrementalAutosaveData> data_; };
}
